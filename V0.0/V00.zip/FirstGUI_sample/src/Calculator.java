import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.events.SelectionEvent;


public class Calculator extends Composite implements SelectionListener {

	private final FormToolkit toolkit = new FormToolkit(Display.getCurrent());
	private Label lblNewLabel;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Calculator(Composite parent, int style) {
		super(parent, style);
		addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
				toolkit.dispose();
			}
		});
		toolkit.adapt(this);
		toolkit.paintBordersFor(this);
		setLayout(new FormLayout());
		
		lblNewLabel = new Label(this, SWT.NONE);
		lblNewLabel.setAlignment(SWT.RIGHT);
		FormData fd_lblNewLabel = new FormData();
		fd_lblNewLabel.left = new FormAttachment(0, 10);
		fd_lblNewLabel.right = new FormAttachment(100, -10);
		fd_lblNewLabel.bottom = new FormAttachment(0, 42);
		fd_lblNewLabel.top = new FormAttachment(0, 20);
		lblNewLabel.setLayoutData(fd_lblNewLabel);
		toolkit.adapt(lblNewLabel, true, true);
		lblNewLabel.setText("0");
		
		Composite composite = new Composite(this, SWT.NONE);
		composite.setLayout(new GridLayout(4, false));
		FormData fd_composite = new FormData();
		fd_composite.bottom = new FormAttachment(100, -10);
		fd_composite.top = new FormAttachment(lblNewLabel, 8);
		fd_composite.left = new FormAttachment(0, 10);
		fd_composite.right = new FormAttachment(100, -10);
		composite.setLayoutData(fd_composite);
		toolkit.adapt(composite);
		toolkit.paintBordersFor(composite);
		
		Button btnOne = new Button(composite, SWT.NONE);
		GridData gd_btnOne = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnOne.widthHint = 50;
		btnOne.setLayoutData(gd_btnOne);
		toolkit.adapt(btnOne, true, true);
		btnOne.setText("1");
		
		Button btnTwo = new Button(composite, SWT.NONE);
		GridData gd_btnTwo = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnTwo.widthHint = 50;
		btnTwo.setLayoutData(gd_btnTwo);
		toolkit.adapt(btnTwo, true, true);
		btnTwo.setText("2");
		
		Button btnThree = new Button(composite, SWT.NONE);
		GridData gd_btnThree = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnThree.widthHint = 50;
		btnThree.setLayoutData(gd_btnThree);
		toolkit.adapt(btnThree, true, true);
		btnThree.setText("3");
		
		Button btnPlus = new Button(composite, SWT.NONE);
		GridData gd_btnPlus = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnPlus.widthHint = 50;
		btnPlus.setLayoutData(gd_btnPlus);
		toolkit.adapt(btnPlus, true, true);
		btnPlus.setText("+");
		
		Button btnFour = new Button(composite, SWT.NONE);
		GridData gd_btnFour = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnFour.widthHint = 50;
		btnFour.setLayoutData(gd_btnFour);
		toolkit.adapt(btnFour, true, true);
		btnFour.setText("4");
		
		Button btnFive = new Button(composite, SWT.NONE);
		GridData gd_btnFive = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnFive.widthHint = 50;
		btnFive.setLayoutData(gd_btnFive);
		toolkit.adapt(btnFive, true, true);
		btnFive.setText("5");
		
		Button btnSix = new Button(composite, SWT.NONE);
		GridData gd_btnSix = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnSix.widthHint = 50;
		btnSix.setLayoutData(gd_btnSix);
		toolkit.adapt(btnSix, true, true);
		btnSix.setText("6");
		
		Button btnMinus = new Button(composite, SWT.NONE);
		GridData gd_btnMinus = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnMinus.widthHint = 50;
		btnMinus.setLayoutData(gd_btnMinus);
		toolkit.adapt(btnMinus, true, true);
		btnMinus.setText("-");
		
		Button btnSeven = new Button(composite, SWT.NONE);
		GridData gd_btnSeven = new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1);
		gd_btnSeven.widthHint = 50;
		btnSeven.setLayoutData(gd_btnSeven);
		toolkit.adapt(btnSeven, true, true);
		btnSeven.setText("7");
		
		Button btnEight = new Button(composite, SWT.NONE);
		GridData gd_btnEight = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnEight.widthHint = 50;
		btnEight.setLayoutData(gd_btnEight);
		toolkit.adapt(btnEight, true, true);
		btnEight.setText("8");
		
		Button btnNine = new Button(composite, SWT.NONE);
		GridData gd_btnNine = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNine.widthHint = 50;
		btnNine.setLayoutData(gd_btnNine);
		toolkit.adapt(btnNine, true, true);
		btnNine.setText("9");
		
		Button btnMultiply = new Button(composite, SWT.NONE);
		GridData gd_btnMultiply = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnMultiply.widthHint = 50;
		btnMultiply.setLayoutData(gd_btnMultiply);
		toolkit.adapt(btnMultiply, true, true);
		btnMultiply.setText("*");
		
		Button btnDot = new Button(composite, SWT.NONE);
		GridData gd_btnDot = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnDot.widthHint = 50;
		btnDot.setLayoutData(gd_btnDot);
		toolkit.adapt(btnDot, true, true);
		btnDot.setText(".");
		
		Button btnZero = new Button(composite, SWT.NONE);
		GridData gd_btnZero = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnZero.widthHint = 50;
		btnZero.setLayoutData(gd_btnZero);
		toolkit.adapt(btnZero, true, true);
		btnZero.setText("0");
		
		Button btnEqual = new Button(composite, SWT.NONE);
		GridData gd_btnEqual = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnEqual.widthHint = 50;
		btnEqual.setLayoutData(gd_btnEqual);
		toolkit.adapt(btnEqual, true, true);
		btnEqual.setText("=");
		
		Button btnDivide = new Button(composite, SWT.NONE);
		GridData gd_btnDivide = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnDivide.widthHint = 50;
		btnDivide.setLayoutData(gd_btnDivide);
		toolkit.adapt(btnDivide, true, true);
		btnDivide.setText("/");
		
		btnOne.addSelectionListener(this);
		btnTwo.addSelectionListener(this);
		btnThree.addSelectionListener(this);
		btnFour.addSelectionListener(this);
		btnFive.addSelectionListener(this);
		btnSix.addSelectionListener(this);
		btnSeven.addSelectionListener(this);
		btnEight.addSelectionListener(this);
		btnNine.addSelectionListener(this);
		btnZero.addSelectionListener(this);

	}
	
	public static void main(String[] args){
	    Display display = new Display();
	    Shell shell = new Shell(display);
	    Calculator calc = new Calculator(shell, SWT.NONE);
	    calc.pack();
	    shell.pack();
	    shell.open();
	    while(!shell.isDisposed()){
	        if(!display.readAndDispatch()) display.sleep();
	    }
	}

	@Override
	public void widgetDefaultSelected(SelectionEvent e) {
	}

	@Override
	public void widgetSelected(SelectionEvent e) {
		Button b = (Button)e.getSource();
		int num = Integer.parseInt(lblNewLabel.getText());
		num += Integer.parseInt(b.getText());
		lblNewLabel.setText(num+"");

	}
}
